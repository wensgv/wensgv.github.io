# Bacterial Growth Project

TODO: complete documentation.
